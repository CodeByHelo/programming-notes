Resumos de Programação Básica

Repositório com anotações curtas, exemplos e conceitos que estou estudando ao longo da minha jornada em programação. A ideia é manter tudo organizado e fácil de consultar.

# Resumos de Programação Básica

## 00 - Conceitos iniciais
## 01 - Primeiros Comandos
## 02 - Condicionais
## 03 - Repetições

- [Resumos de Programação Básica](#resumos-de-programação-básica)
  - [00 - Conceitos iniciais](#00---conceitos-iniciais)
  - [01 - Primeiros Comandos](#01---primeiros-comandos)
  - [02 - Condicionais](#02---condicionais)
  - [03 - Repetições](#03---repetições)
